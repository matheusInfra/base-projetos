
let listaAmigos = [];


function adicionarAmigo() {
    let inputNome = document.getElementById("amigo");
    let nome = inputNome.value.trim();

    if (nome === "") {
        alert("Por favor, digite um nome válido!");
        return;
    }

    listaAmigos.push(nome);

    atualizarLista();

    inputNome.value = "";
}

function atualizarLista() {
    let listaElement = document.getElementById("listaAmigos");
    listaElement.innerHTML = ""; 

    listaAmigos.forEach(nome => {
        let item = document.createElement("li");
        item.textContent = nome;
        listaElement.appendChild(item);
    });
}

function sortearAmigo() {
    if (listaAmigos.length === 0) {
        alert("A lista está vazia! Adicione pelo menos um nome antes de sortear.");
        return;
    }

    let indiceSorteado = Math.floor(Math.random() * listaAmigos.length);
    let amigoSorteado = listaAmigos[indiceSorteado];

    let resultadoElement = document.getElementById("resultado");
    resultadoElement.innerHTML = `<li>🎉 ${amigoSorteado} foi sorteado! 🎉</li>`;
}
